package cripto.enigma;

import java.util.Locale;
import java.util.Scanner;

/**
 * Un AppEncriptar es una aplicación que codifica textos leidos por la entrada estándar.
 */
/*
 * Esta clase crea y usa objetos MaquinaEnigma en su ejecución (ver "start").
 *
 * En esta clase no hay que hacer nada: sólo conseguir que funcione!
 */
public class AppEncriptar {

	/*
	 * Para codificar los textos leidos se usa una MaquinaEnigma.
	 */
	private MaquinaEnigma maquinaEnigma;

	/*
	 * Para leer el contenido de la entrada estándar se usa un Scanner.
	 */
	private Scanner stdInputScanner;

	/**
	 * Construye un nuevo AppEncriptar.
	 */
	public AppEncriptar() {
		/*
		 * Crear el Scanner para leer el contenido de la entrada estándar.
		 */
		stdInputScanner = new Scanner(System.in);

		/*
		 * Configurar ese Scanner para leer números en coma flotante con el formato
		 * habitual (es decir, usar . para representar la ,)
		 */
		stdInputScanner.useLocale(Locale.US);
	}

	/**
	 * Arranque.
	 */
	public void start() {
		String clave = promptLine("Introduzca clave y pulse ENTER");
		maquinaEnigma = new MaquinaEnigma(clave);
		do {
			String texto = promptLine("Introduzca texto a encriptar y pulse ENTER");
			String codificado = maquinaEnigma.codificar(texto);

			System.out.println("Texto codificado: @" + codificado + "@");
		} while (promptBoolean("Continuar[true|false]?"));
	}

	/**
	 * Devuelve el valor lógico (true/false) introducido por el usuario.
	 */
	private boolean promptBoolean(String prompt) {
		System.out.println(prompt);
		boolean b = stdInputScanner.nextBoolean();
		return b;
	}

	/**
	 * Devuelve el resto de la línea introducida por el usuario.
	 */
	private String promptLine(String prompt) {
		System.out.println(prompt);
		String s = stdInputScanner.nextLine();
		return s;
	}

	/**
	 * Punto de arranque de la aplicación.
	 */
	public static void main(String[] args) {
		AppEncriptar app = new AppEncriptar();
		app.start();
	}
}
