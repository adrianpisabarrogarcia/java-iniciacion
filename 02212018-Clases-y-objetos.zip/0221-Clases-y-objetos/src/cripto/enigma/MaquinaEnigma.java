package cripto.enigma;

/**
 * Los objetos de esta clase son máquinas de criptografía que codifican y descodifican
 * textos.
 *
 * Para codificar/descodificar textos una MaquinaEnigma usa una clave.
 *
 * Esa clave es un String con longitud igual a 26 (el número de letras del alfabeto):
 *
 * ABCDEFGHIJKLMNOPQRSTUVWXYZ
 */
/*
 * OBSERVACION
 *
 * Para codificar un texto una MaquinaEnigma sustituye cada carácter del texto por el
 * carácter que ocupa la posición "k" (= código UNICODE del carácter original menos código
 * del carácter 'A') en la clave de la MaquinaEnigma
 *
 * Por ejemplo, si la clave de una MaquinaEnigma es "DEFGHIJKLMNOPQRSTUVWXYZABC", esa
 * máquina codificará el texto "ABC" en "DEF".
 *
 * Una MaquinaEnigma NO CODIFICA los caracteres del texto original cuyo código UNICODE
 * menos el código del carácter 'A' sea mayor que la longitud de la clave.
 */
public class MaquinaEnigma {

	/*
	 * TODO
	 *
	 * elegir las variables adecuadas.
	 *
	 * Una MaquinaEnigma debe memorizar su clave, que se configura en la constructora.
	 */

	/**
	 * Construye un nuevo MaquinaEnigma.
	 *
	 * PRECONDICION: la longitud de "clave" es 26.
	 */
	public MaquinaEnigma(String clave) {
		/*
		 * TODO Completar
		 *
		 * El nuevo MaquinaEnigma debe memorizar la clave.
		 */
	}

	/**
	 * Devuelve un nuevo String que es el resultado de codificar el "texto" pasado como
	 * parámetro.
	 */
	public String codificar(String texto) {
		StringBuilder sb = new StringBuilder();

		/*
		 * TODO Completar
		 *
		 * OBLIGATORIO: USAR el objeto "sb"
		 *
		 * añadir a sb la codificación de los caracteres de "texto"
		 *
		 * (ver OBSERVACION arriba)
		 *
		 * Métodos que necesitarás usar de un String:
		 *
		 * public int length() devuelve la longitud del String
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#length--
		 *
		 * public char charAt(int index) devuelve el carácter en la posición especificada
		 * por index. si index no es 0 <= index < la longitud del String, error!
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#charAt-int-
		 *
		 * Métodos que necesitarás usar de un StringBuilder:
		 *
		 * public void append(char c) añade el carácter c al StringBuilder
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-
		 * char-
		 */

		String string = sb.toString();    // toString devuelve un nuevo String con una
										    // secuencia de caracteres igual a (la de) sb.
		return string;
	}

	/**
	 * Devuelve un nuevo String que es el resultado de DEScodificar el "texto" pasado como
	 * parámetro.
	 *
	 * PRECONDICION: el "texto" pasado como parámetro ha sido codificado con esta
	 * MaquinaEnigma.
	 */
	public String descodificar(String texto) {
		/*
		 * TODO Completar (EXTRA)
		 */
		return "";
	}

	/**
	 * Devuelve la clave usada por este MaquinaEnigma para codificar textos.
	 */
	public String getClave() {
		/*
		 * TODO Completar (EXTRA)
		 */
		return "";
	}
}
