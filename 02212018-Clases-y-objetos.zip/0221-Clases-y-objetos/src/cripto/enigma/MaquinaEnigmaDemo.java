package cripto.enigma;

/**
 * Clase con main para comprobar el resultado de codificar de un MaquinaEnigma.
 */
public class MaquinaEnigmaDemo {

	public static void main(String[] args) {
		caso(new MaquinaEnigma("DEFGHIJKLMNOPQRSTUVWXYZABC"), "ABC", "DEF");
		caso(new MaquinaEnigma(""), "ABC", "ABC");
	}

	/**
	 * Comprueba el resultado de MaquinaEnigma.codificar(String)
	 *
	 * @param maquinaEnigma
	 *            la MaquinaEnigma a usar para codificar el texto
	 * @param texto
	 *            el texto a codificar
	 * @param esperado
	 *            el resultado esperado
	 */
	private static void caso(MaquinaEnigma maquinaEnigma, String texto,
			String esperado) {
		System.out.println("Calculando maquinaEnigma.codificar(" + texto
				+ ") Clave: " + maquinaEnigma.getClave());

		String b = maquinaEnigma.codificar(texto);
		if (esperado.equals(b)) {
			System.out.println("\tPasa!");
		} else {
			System.out.println("\tERROR! El resultado debe ser: " + esperado
					+ " pero es: " + b);
		}
	}

}
