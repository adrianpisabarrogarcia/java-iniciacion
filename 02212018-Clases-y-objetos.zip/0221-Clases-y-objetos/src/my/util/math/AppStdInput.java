package my.util.math;

import java.util.Locale;
import java.util.Scanner;

/**
 * Un AppStdInput es una aplicación que lee coeficientes de polinomios de segundo grado
 * de la entrada estándar, y calcula las soluciones reales de cada uno.
 */
/*
 * Esta clase crea y usa objetos Poly2 en su ejecución (ver "start").
 *
 * En esta clase no hay que hacer nada: sólo conseguir que funcione!
 */
public class AppStdInput {

	/*
	 * Para leer el contenido de la entrada estándar se usa un Scanner.
	 */
	private Scanner stdInputScanner;

	public AppStdInput() {
		/*
		 * Crear el Scanner para leer el contenido de la entrada estándar.
		 */
		stdInputScanner = new Scanner(System.in);

		/*
		 * Configurar ese Scanner para leer números en coma flotante con el formato
		 * habitual (es decir, usar . para representar la ,)
		 */
		stdInputScanner.useLocale(Locale.US);
	}

	/**
	 * Arranque.
	 */
	public void start() {
		do {
			double a = promptDouble("double a?");
			double b = promptDouble("double b?");
			double c = promptDouble("double c?");

			Poly2 poly = new Poly2(a, b, c);
			System.out.println(
					"Coeficientes polinomio: a=" + a + "; b=" + b + "; c=" + c);

			int solucionesReales = poly.cuantosCerosReales();
			if (solucionesReales == 1) {
				double solucion = poly.calcularMayorCero();
				System.out.println("Solucion real unica: " + solucion);
			} else if (solucionesReales == 2) {
				double solucionUno = poly.calcularMayorCero();
				double solucionDos = poly.calcularMenorCero();
				System.out.println("Dos soluciones reales: " + solucionUno + "; "
						+ solucionDos);
			} else {
				System.out.println("No hay soluciones reales");
			}
		} while (promptBoolean("Continuar[true|false]?"));
	}

	/**
	 * Devuelve el valor lógico (true/false) introducido por el usuario.
	 */
	private boolean promptBoolean(String prompt) {
		System.out.println(prompt);
		return stdInputScanner.nextBoolean();
	}

	/**
	 * Devuelve el valor double introducido por el usuario.
	 */
	private double promptDouble(String prompt) {
		System.out.println(prompt);
		return stdInputScanner.nextDouble();
	}

	/**
	 * Punto de arranque de la aplicación.
	 */
	public static void main(String[] args) {
		AppStdInput app = new AppStdInput();
		app.start();
	}
}
