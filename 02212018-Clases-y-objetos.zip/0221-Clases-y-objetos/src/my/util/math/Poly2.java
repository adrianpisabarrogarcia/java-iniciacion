package my.util.math;

/**
 * Los objetos de esta clase son/representan polinomios de segundo grado.
 *
 * Un polinomio de segundo grado tiene tres coeficientes y se suele escribir:
 * ax2+bx+c Los coeficientes "b" y/o "c" pueden ser cero, pero NUNCA el
 * coeficiente "a".
 *
 * Los ceros de un polinomio P(x) son las soluciones de la ecuación P(x) = 0.
 *
 * Un polinomio de segundo grado tiene siempre dos ceros, que pueden ser reales
 * o complejos.
 *
 * Un objeto Poly2 tiene métodos para conocer cuántos ceros reales tiene, cuál
 * es el mayor de esos ceros, cuál es el menor...
 */
/*
 * Los ceros de un polinomio de segundo grado P(x) = ax2+bx+c son las soluciones
 * de la ecuación ax2+bx+c = 0.
 *
 * Esa ecuación tiene UNA solución real si: b2 - 4ac es cero.
 *
 * Esa ecuación tiene DOS soluciones reales si: b2 - 4ac es > 0.
 *
 * Esa ecuación tiene DOS soluciones complejas si: b2 - 4ac es < 0.
 *
 * En Java, para calcular la raíz cuadrada de un double, USAR el método STATIC
 * de la clase java.lang.Math La clase Math es una de las disponibles en la
 * distribución estándar.
 *
 * public static double sqrt(double a) devuelve la raíz cuadrada de a.
 *
 * Ver:
 * https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-
 */
public class Poly2 {

	/*
	 * TODO
	 *
	 * elegir las variables adecuadas para representar un polinomio de segundo
	 * grado.
	 */

	/**
	 * Construye un nuevo Poly2 que representa el polinomio de segundo grado
	 * ax2+bx+c.
	 *
	 * PRECONDICION: el coeficiente a es distinto de cero.
	 */

	public Poly2(double a, double b, double c) {
		int x = 1;
		/*
		 * TODO Completar
		 */

		double Poly2 = a * Math.pow(x, 2) + b * x + c;

	}

	/**
	 * Devuelve el mayor de los ceros reales de este Poly2.
	 *
	 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
	 *
	 * PRECONDICION: este Poly2 tiene ceros reales.
	 */
	public double calcularMayorCero() {
		/*
		 * TODO Completar
		 */
		
		ackage my.util.math;

		 * Los objetos de esta clase son/representan polinomios de segundo grado.
		/*
		 * Los ceros de un polinomio de segundo grado P(x) = ax2+bx+c son las soluciones de la
		 * ecuación ax2+bx+c = 0.
		 *
		 * Esa ecuación tiene UNA solución real si: b2 - 4ac es cero.
		 *
		 * Esa ecuación tiene DOS soluciones reales si: b2 - 4ac es > 0.
		 *
		 * Esa ecuación tiene DOS soluciones complejas si: b2 - 4ac es < 0.
		 *
		 * En Java, para calcular la raíz cuadrada de un double,
		 * USAR el método STATIC de la clase java.lang.Math
		 * La clase Math es una de las disponibles en la distribución estándar.
		 *
		 * 		public static double sqrt(double a)
		 * 			devuelve la raíz cuadrada de a.
		 *
		 * 			Ver:
		 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-
		 */
		public class Poly2 {

			/*
			 * TODO
			 *
			 * elegir las variables adecuadas para representar un polinomio de segundo grado.
			 */

			/**
			 * Construye un nuevo Poly2 que representa el polinomio de segundo grado ax2+bx+c.
			 *
			 * PRECONDICION: el coeficiente a es distinto de cero.
			 */
			
			
			
			
			
			
			public Poly2(double a, double b, double c) { int x=1;
				/*
				 * TODO Completar
				 */
				
			
				double Poly2=a*Math.pow(x, 2)+b*x +c;
				
			}

			/**
			 * Devuelve el mayor de los ceros reales de este Poly2.
			 *
			 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
			 *
			 * PRECONDICION: este Poly2 tiene ceros reales.
			 */
			public double calcularMayorCero() {
				/*
				 * TODO Completar
				 */
				
				
				
				
				
				
				return 0;
			}

			/**
			 * Devuelve el menor de los ceros reales de este Poly2.
			 *
			 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
			 *
			 * PRECONDICION: este Poly2 tiene ceros reales.
			 */
			public double calcularMenorCero() {
				/*
				 * TODO Completar
				 */
				return 0;
			}

			/**
			 * Devuelve el número de ceros reales de este Poly2.
			 */
			public int cuantosCerosReales() {
				/*
				 * TODO Completar
				 */
				return 0;
			}

			/**
			 * Devuelve el valor de este Poly2 en el punto "x" de la recta real.
			 */
			public double evaluar(double x) {
				return 0;
			}

			/**
			 * Devuelve UN NUEVO String que representa este Poly2.
			 */
			@Overrideackage my.util.math;

			 * Los objetos de esta clase son/representan polinomios de segundo grado.
			/*
			 * Los ceros de un polinomio de segundo grado P(x) = ax2+bx+c son las soluciones de la
			 * ecuación ax2+bx+c = 0.
			 *
			 * Esa ecuación tiene UNA solución real si: b2 - 4ac es cero.
			 *
			 * Esa ecuación tiene DOS soluciones reales si: b2 - 4ac es > 0.
			 *
			 * Esa ecuación tiene DOS soluciones complejas si: b2 - 4ac es < 0.
			 *
			 * En Java, para calcular la raíz cuadrada de un double,
			 * USAR el método STATIC de la clase java.lang.Math
			 * La clase Math es una de las disponibles en la distribución estándar.
			 *
			 * 		public static double sqrt(double a)
			 * 			devuelve la raíz cuadrada de a.
			 *
			 * 			Ver:
			 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-
			 */
			public class Poly2 {

				/*
				 * TODO
				 *
				 * elegir las variables adecuadas para representar un polinomio de segundo grado.
				 */

				/**
				 * Construye un nuevo Poly2 que representa el polinomio de segundo grado ax2+bx+c.
				 *
				 * PRECONDICION: el coeficiente a es distinto de cero.
				 */
				
				
				
				
				
				
				public Poly2(double a, double b, double c) { int x=1;
					/*
					 * TODO Completar
					 */
					
				
					double Poly2=a*Math.pow(x, 2)+b*x +c;
					
				}

				/**
				 * Devuelve el mayor de los ceros reales de este Poly2.
				 *
				 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
				 *
				 * PRECONDICION: este Poly2 tiene ceros reales.
				 */
				public double calcularMayorCero() {
					/*
					 * TODO Completar
					 */
					
					
					
					
					
					
					return 0;
				}

				/**
				 * Devuelve el menor de los ceros reales de este Poly2.
				 *
				 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
				 *
				 * PRECONDICION: este Poly2 tiene ceros reales.
				 */
				public double calcularMenorCero() {
					/*
					 * TODO Completar
					 */
					return 0;
				}

				/**
				 * Devuelve el número de ceros reales de este Poly2.
				 */
				public int cuantosCerosReales() {
					/*
					 * TODO Completar
					 */
					return 0;
				}

				/**
				 * Devuelve el valor de este Poly2 en el punto "x" de la recta real.
				 */
				public double evaluar(double x) {
					return 0;
				}

				/**
				 * Devuelve UN NUEVO String que representa este Poly2.
				 */
				@Override
				public String toString() {
					StringBuilder sb = new StringBuilder();

					ackage my.util.math;

					 * Los objetos de esta clase son/representan polinomios de segundo grado.
					/*
					 * Los ceros de un polinomio de segundo grado P(x) = ax2+bx+c son las soluciones de la
					 * ecuación ax2+bx+c = 0.
					 *
					 * Esa ecuación tiene UNA solución real si: b2 - 4ac es cero.
					 *
					 * Esa ecuación tiene DOS soluciones reales si: b2 - 4ac es > 0.
					 *
					 * Esa ecuación tiene DOS soluciones complejas si: b2 - 4ac es < 0.
					 *
					 * En Java, para calcular la raíz cuadrada de un double,
					 * USAR el método STATIC de la clase java.lang.Math
					 * La clase Math es una de las disponibles en la distribución estándar.
					 *
					 * 		public static double sqrt(double a)
					 * 			devuelve la raíz cuadrada de a.
					 *
					 * 			Ver:
					 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-
					 */
					public class Poly2 {

						/*
						 * TODO
						 *
						 * elegir las variables adecuadas para representar un polinomio de segundo grado.
						 */

						/**
						 * Construye un nuevo Poly2 que representa el polinomio de segundo grado ax2+bx+c.
						 *
						 * PRECONDICION: el coeficiente a es distinto de cero.
						 */
						
						
						
						
						
						
						public Poly2(double a, double b, double c) { int x=1;
							/*
							 * TODO Completar
							 */
							
						
							double Poly2=a*Math.pow(x, 2)+b*x +c;
							
						}

						/**
						 * Devuelve el mayor de los ceros reales de este Poly2.
						 *
						 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
						 *
						 * PRECONDICION: este Poly2 tiene ceros reales.
						 */
						public double calcularMayorCero() {
							/*
							 * TODO Completar
							 */
							
							
							
							
							
							
							return 0;
						}

						/**
						 * Devuelve el menor de los ceros reales de este Poly2.
						 *
						 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
						 *
						 * PRECONDICION: este Poly2 tiene ceros reales.
						 */
						public double calcularMenorCero() {
							/*
							 * TODO Completar
							 */
							return 0;
						}

						/**
						 * Devuelve el número de ceros reales de este Poly2.
						 */
						public int cuantosCerosReales() {
							/*
							 * TODO Completar
							 */
							return 0;
						}

						/**
						 * Devuelve el valor de este Poly2 en el punto "x" de la recta real.
						 */
						public double evaluar(double x) {
							return 0;
							ackage my.util.math;

							 * Los objetos de esta clase son/representan polinomios de segundo grado.
							/*
							 * Los ceros de un polinomio de segundo grado P(x) = ax2+bx+c son las soluciones de la
							 * ecuación ax2+bx+c = 0.
							 *
							 * Esa ecuación tiene UNA solución real si: b2 - 4ac es cero.
							 *
							 * Esa ecuación tiene DOS soluciones reales si: b2 - 4ac es > 0.
							 *
							 * Esa ecuación tiene DOS soluciones complejas si: b2 - 4ac es < 0.
							 *
							 * En Java, para calcular la raíz cuadrada de un double,
							 * USAR el método STATIC de la clase java.lang.Math
							 * La clase Math es una de las disponibles en la distribución estándar.
							 *
							 * 		public static double sqrt(double a)
							 * 			devuelve la raíz cuadrada de a.
							 *
							 * 			Ver:
							 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-
							 */
							public class Poly2 {

								/*
								 * TODO
								 *
								 * elegir las variables adecuadas para representar un polinomio de segundo grado.
								 */

								/**
								 * Construye un nuevo Poly2 que representa el polinomio de segundo grado ax2+bx+c.
								 *
								 * PRECONDICION: el coeficiente a es distinto de cero.
								 */
								
								
								
								
								
								
								public Poly2(double a, double b, double c) { int x=1;
									/*
									 * TODO Completar
									 */
									
								
									double Poly2=a*Math.pow(x, 2)+b*x +c;
									
								}

								/**
								 * Devuelve el mayor de los ceros reales de este Poly2.
								 *
								 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
								 *
								 * PRECONDICION: este Poly2 tiene ceros reales.
								 */
								public double calcularMayorCero() {
									/*
									 * TODO Completar
									 */
									
									
									
									
									
									
									return 0;
								}

								/**
								 * Devuelve el menor de los ceros reales de este Poly2.
								 *
								 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
								 *
								 * PRECONDICION: este Poly2 tiene ceros reales.
								 */
								public double calcularMenorCero() {
									/*
									 * TODO Completar
									 */
									return 0;
								}

								/**
								 * Devuelve el número de ceros reales de este Poly2.
								 */
								public int cuantosCerosReales() {
									/*
									 * TODO Completar
									 */
									return 0;
								}

								/**
								 * Devuelve el valor de este Poly2 en el punto "x" de la recta real.
								 */
								public double evaluar(double x) {
									return 0;
								}

								/**
								 * Devuelve UN NUEVO String que representa este Poly2.
								 */
								@Override
								public String toString() {
									StringBuilder sb = new StringBuilder();

									/*
									 * TODO Completar
									 *
									 * OBLIGATORIO: USAR el objeto "sb"
									 *
									 * Necesitarás usar métodos del objeto "sb":
									 *
									 * 		public void Builder append(double d)
									 * 			añade el texto de la representación decimal de "d" AL  StringBuilder
									 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-double-
									 *
									 * 		public void void append(char ch)
									 * 			añade el carácter "ch" AL  StringBuilder
									 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-char-
									 *
									 * 		public void void append(String s)
									 * 			añade el texto del String "s" AL  StringBuilder
									 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-java.lang.String-
									 *
									 *
									 * ELEGIR el formato que se desee para para representar el polinomio
									 *
									 * Por ejemplo, si los coeficientes del polinomio son 1, 2, y 1,
									 * el String devuelto puede ser:
									 * 			"1	2	1"
									 *
									 * o también:
									 * 			"a=1; b=2; c=1"
									 */

									String string = sb.toString();
									return string;
								}

							}
			}

						/**
						 * Devuelve UN NUEVO String que representa este Poly2.
						 */
						@Override
						public String toString() {
							StringBuilder sb = new StringBuilder();

							/*
							 * TODO Completar
							 *
							 * OBLIGATORIO: USAR el objeto "sb"
							 *
							 * Necesitarás usar métodos del objeto "sb":
							 *
							 * 		public void Builder append(double d)
							 * 			añade el texto de la representación decimal de "d" AL  StringBuilder
							 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-double-
							 *
							 * 		public void void append(char ch)
							 * 			añade el carácter "ch" AL  StringBuilder
							 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-char-
							 *
							 * 		public void void append(String s)
							 * 			añade el texto del String "s" AL  StringBuilder
							 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-java.lang.String-
							 *
							 *
							 * ELEGIR el formato que se desee para para representar el polinomio
							 *
							 * Por ejemplo, si los coeficientes del polinomio son 1, 2, y 1,
							 * el String devuelto puede ser:
							 * 			"1	2	1"
							 *
							 * o también:
							 * 			"a=1; b=2; c=1"
							 */

							String string = sb.toString();
							return string;
						}

					}
		/*
					 * TODO Completar
					 *
					 * OBLIGATORIO: USAR el objeto "sb"
					 *
					 * Necesitarás usar métodos del objeto "sb":
					 *
					 * 		public void Builder append(double d)
					 * 			añade el texto de la representación decimal de "d" AL  StringBuilder
					 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-double-
					 *
					 * 		public void void append(char ch)
					 * 			añade el carácter "ch" AL  StringBuilder
					 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-char-
					 *
					 * 		public void void append(String s)
					 * 			añade el texto del String "s" AL  StringBuilder
					 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-java.lang.String-
					 *
					 *
					 * ELEGIR el formato que se desee para para representar el polinomio
					 *
					 * Por ejemplo, si los coeficientes del polinomio son 1, 2, y 1,
					 * el String devuelto puede ser:
					 * 			"1	2	1"
					 *
					 * o también:
					 * 			"a=1; b=2; c=1"
					 */

					String string = sb.toString();
					return string;
				}

			}

			@Override
			public String toString() {
				StringBuilder sb = new StringBuilder();

				/*
				 * TODO Completar
				 *
				 * OBLIGATORIO: USAR el objeto "sb"
				 *
				 * Necesitarás usar métodos del objeto "sb":
				 *
				 * 		public void Builder append(double d)
				 * 			añade el texto de la representación decimal de "d" AL  StringBuilder
				 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-double-
				 *
				 * 		public void void append(char ch)
				 * 			añade el carácter "ch" AL  StringBuilder
				 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-char-
				 *
				 * 		public void void append(String s)
				 * 			añade el texto del String "s" AL  StringBuilder
				 * 			https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append-java.lang.String-
				 *
				 *
				 * ELEGIR el formato que se desee para para representar el polinomio
				 *
				 * Por ejemplo, si los coeficientes del polinomio son 1, 2, y 1,
				 * el String devuelto puede ser:
				 * 			"1	2	1"
				 *
				 * o también:
				 * 			"a=1; b=2; c=1"
				 */

				String string = sb.toString();
				return string;
			}

		}

		
		
		
		
		return 0;
	}

	/**
	 * Devuelve el menor de los ceros reales de este Poly2.
	 *
	 * Si este Poly2 sólo tiene un cero, devuelve ese cero.
	 *
	 * PRECONDICION: este Poly2 tiene ceros reales.
	 */
	public double calcularMenorCero() {
		/*
		 * TODO Completar
		 */
		return 0;
	}

	/**
	 * Devuelve el número de ceros reales de este Poly2.
	 */
	public int cuantosCerosReales() {
		/*
		 * TODO Completar
		 */
		return 0;
	}

	/**
	 * Devuelve el valor de este Poly2 en el punto "x" de la recta real.
	 */
	public double evaluar(double x) {
		return 0;
	}

	/**
	 * Devuelve UN NUEVO String que representa este Poly2.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		/*
		 * TODO Completar
		 *
		 * OBLIGATORIO: USAR el objeto "sb"
		 *
		 * Necesitarás usar métodos del objeto "sb":
		 *
		 * public void Builder append(double d) añade el texto de la representación
		 * decimal de "d" AL StringBuilder
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append
		 * -double-
		 *
		 * public void void append(char ch) añade el carácter "ch" AL StringBuilder
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append
		 * -char-
		 *
		 * public void void append(String s) añade el texto del String "s" AL
		 * StringBuilder
		 * https://docs.oracle.com/javase/8/docs/api/java/lang/StringBuilder.html#append
		 * -java.lang.String-
		 *
		 *
		 * ELEGIR el formato que se desee para para representar el polinomio
		 *
		 * Por ejemplo, si los coeficientes del polinomio son 1, 2, y 1, el String
		 * devuelto puede ser: "1	2	1"
		 *
		 * o también: "a=1; b=2; c=1"
		 */

		String string = sb.toString();
		return string;
	}

}
