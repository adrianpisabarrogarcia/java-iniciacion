package sopa.letras;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.util.Scanner;

import ehu.swing.CanvasWindow;

/**
 * Un AppStdInput es una aplicación para jugar a la sopa de letras.
 *
 * Lee la configuración de una sopa de letras de un archivo y un diccionario de otro.
 *
 * A continuación se muestra una ventana con el contenido de la sopa de letras, y se piden
 * al usuario:
 *
 * 1) las coordenadas (fila, columna) de una casilla en la sopa de letras, en la cual cree
 * haber encontrado una palabra
 *
 * la casilla (0, 0) es la SUPERIOR IZQUIERDA la casilla (C-1, F-1) es la INFERIOR DERECHA
 * C: número de columnas (columnas => eje X) F: número de filas (filas => eje Y)
 *
 * 2) el número de letras de la palabra reconocida
 *
 * 3) la dirección en la que se encuentra la palabra reconocida El usuario introducirá un
 * par de enteros (dx, dy) indicando la dirección (1, 0): hacia la derecha (horizontal)
 * (-1, 0): hacia la izquierda (horizontal)
 *
 * (0, -1): vertical (hacia arriba) (0, 1): vertical (hacia abajo)
 *
 * (1, -1): hacia la derecha y arriba (45 grados arriba) (1, 1): hacia la derecha y hacia
 * abajo (45 grados abajo)
 *
 * (-1, -1): hacia la izquierda y arriba (45 grados arriba) (-1, 1): hacia la izquierda y
 * hacia abajo (45 grados abajo)
 *
 * Se cambia el color de las casillas afectadas según se haya acertado o no.
 */
/*
 * Esta clase crea y usa objetos SopaDeLetras y Diccionario en su ejecución (ver "start").
 *
 * En esta clase no hay que hacer nada: sólo conseguir que funcione!
 */
public class Aplicacion {

	/*
	 * Una "constante global"
	 */
	private static final String RUTA_ARCHIVO_CONFIGURACION = "sopas.config.spanish/00";
	// "sopas.config.spanish/00"
	// "sopas.config.spanish/01-tildes"

	/*
	 * Una "constante global"
	 */
	private static final String RUTA_ARCHIVO_DICIONARIO = "diccionarios.spanish/words.spanish.tilde";

	/*
	 * Para visualizar el contenido de la sopa de letras.
	 *
	 * Un canvas es una ventana con un lienzo para dibujar cículos, líneas, etc.
	 */
	private CanvasWindow canvas = new CanvasWindow();

	/*
	 * Diccionario para validar las palabras que selecciona el usuario.
	 */
	private Diccionario diccionario = new Diccionario();

	/*
	 * Para leer el contenido de la entrada estándar se usa un Scanner.
	 */
	private Scanner input = new Scanner(System.in);

	/*
	 * La sopa de letras propiamente dicha.
	 */
	private SopaDeLetras sopa = new SopaDeLetras();

	/*
	 * Variables con informacion para la visualización de la sopa de letras.
	 *
	 * NO HAY QUE HACER NADA CON ESTO
	 */
	private int	xCellSize;	 // tamaño de las casillas en pixeles.
	private int	xSepHoriz;	 // margen horizontal en el dibujado de la sopa de letras
	private int	xSepVert;	 // margen vertical

	/**
	 * Arranque.
	 */
	public void start() throws FileNotFoundException {
		diccionario.leer(RUTA_ARCHIVO_DICIONARIO);
		sopa.leerConfiguracion(RUTA_ARCHIVO_CONFIGURACION);
		configurarVista();

		while (true) {
			int fila = prompt("Fila? [-1 para terminar]");
			if (fila == -1) {
				break;
			}
			int columna = prompt("Columna?");
			int n = prompt("Letras?");
			int deltaX = prompt(
					"Desplazamiento eje horizontal [-1:izquierda|0|derecha:+1]?");
			int deltaY = prompt(
					"Desplazamiento eje vertical[+1:abajo|0|arriba:-1]?");

			String letras = sopa.jugar(fila, columna, deltaX, deltaY, n);
			boolean b = diccionario.esta(letras);

			Color colorBorde = null;
			if (b) {
				colorBorde = Color.GREEN;
			} else {
				colorBorde = Color.RED;
			}
			dibujarBordeCeldas(fila, columna, n, deltaX, deltaY, colorBorde);
		}
		canvas.setVisible(false);
	}

	/*
	 * NO MODIFICAR
	 */
	private void configurarVista() {
		canvas.clear(Color.WHITE);
		canvas.setColor(Color.BLUE);
		canvas.setVisible(true);
		dibujarCuadricula();
		dibujarLetras();
	}

	/*
	 * NO MODIFICAR
	 */
	private void dibujarBordeCeldas(int fila, int columna, int n, int deltaX,
			int deltaY, Color c) {
		canvas.setColor(c);
		int y = fila;
		int x = columna;
		for (int i = 0; i < n; i++) {
			canvas.drawRect(xSepHoriz + x * xCellSize + 1,
					xSepHoriz + y * xCellSize + 1, xCellSize - 2, xCellSize - 2);
			y = y + deltaY;
			x = x + deltaX;
		}
	}

	/*
	 * NO MODIFICAR
	 */
	private void dibujarCuadricula() {
		int rows = sopa.getFilas();
		int cols = sopa.getColumnas();
		int h = (canvas.canvasHeight - 2) / rows;
		int w = (canvas.canvasWidth - 2) / cols;
		xCellSize = Math.min(h, w);

		xSepHoriz = (canvas.canvasWidth - cols * xCellSize) / 2;
		xSepVert = (canvas.canvasHeight - rows * xCellSize) / 2;

		for (int i = 0, x = xSepHoriz; i <= cols; i++, x = x + xCellSize) {
			canvas.drawLine(x, xSepVert, x, xSepVert + rows * xCellSize);
		}
		for (int i = 0, y = xSepVert; i <= rows; i++, y = y + xCellSize) {
			canvas.drawLine(xSepHoriz, y, xSepHoriz + cols * xCellSize, y);
		}
	}

	/*
	 * NO MODIFICAR
	 */
	private void dibujarLetras() {
		int rows = sopa.getFilas();
		int cols = sopa.getColumnas();
		int y = xSepVert + xCellSize / 2;
		for (int row = 0; row < rows; row = row + 1) {
			int x = xSepHoriz + xCellSize / 2;
			for (int col = 0; col < cols; col = col + 1) {
				char ch = sopa.getCharAt(row, col);
				canvas.drawCharCentered(x, y, ch);

				x = x + xCellSize;
			}
			y = y + xCellSize;
		}
	}

	/**
	 * Devuelve el valor entero introducido por el usuario.
	 */
	private int prompt(String prompt) {
		System.out.println(prompt);
		return input.nextInt();
	}

	public static void main(String[] args) throws FileNotFoundException {
		Aplicacion menu = new Aplicacion();
		menu.start();
	}
}
