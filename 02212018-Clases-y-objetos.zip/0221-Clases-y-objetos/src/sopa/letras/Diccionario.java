package sopa.letras;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Un diccionario es un conjunto de palabras (objetos String).
 *
 * Un diccionario es capaz de añadir al conjunto de palabras memorizadas las leidas de un
 * archivo con el formato adecuado.
 *
 * Un diccionario distingue letras mayúsculas y minúsculas.
 */
public class Diccionario {
	private ArrayList<String> stringList;

	/**
	 * Construye un nuevo diccionario vacío.
	 *
	 * Para añadir palabras al diccionario, usar public void load(String inputFilePath)
	 */
	public Diccionario() {
		stringList = new ArrayList<>();
	}

	/**
	 * Devuelve el número de palabras contenidas en este diccionario.
	 */
	public int entradas() {
		/*
		 * TODO Completar
		 */
		return 0;
	}

	/**
	 * Devuelve true si este diccionario contiene la "palabra".
	 *
	 * Un diccionario NO distingue letras mayúsculas y minúsculas.
	 *
	 * Por tanto, si "palabra" es "Bosque" y este diccionario contiene esa palabra pero en
	 * minúsculas, devolverá "true".
	 */
	/*
	 * Usar el método equalsIgnoreCase de los objetos String:
	 *			public boolean equalsIgnoreCase(String anotherString)
	 * 				devuelve true si ESTE String es igual a "anotherString"
	 * 				ignorando la diferencia entre mayúsculas y miñusculas.
	 *
	 *  			https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#equalsIgnoreCase-java.lang.String-
	 */
	public boolean esta(String palabra) {
		/*
		 * TODO Completar
		 */
		return false;
	}

	/**
	 * Añade a este diccionario las palabras contenidas en el archivo con la ruta
	 * "inputFilePath".
	 *
	 * Precondiciones:
	 *
	 * El archivo debe tener el formato adecuado.
	 *
	 * Las palabras del archivo no deben estar ya en este diccionario.
	 *
	 * Formato del archivo: Cada línea contiene un número cualquiera de palabras. Una
	 * línea puede estar formada solamente por espacios en blanco.
	 *
	 */
	public void leer(String inputFilePath) throws FileNotFoundException {
		Scanner scanner = new Scanner(new File(inputFilePath));
		while (scanner.hasNext()) {
			String s = scanner.next();
			/*
			 * TODO Completar
			 *
			 * añadir la palabra s al diccionario
			 */
		}
		scanner.close();
	}
}
