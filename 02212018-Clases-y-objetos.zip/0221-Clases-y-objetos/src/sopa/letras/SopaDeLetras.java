package sopa.letras;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Una sopa de letras es una cuadrícula en cuyas celdas hay letras.
 *
 * Un objeto SopaDeLetras tiene métodos para conocer su número de filas, de columnas, la
 * letra que está en una de sus celdas...
 */
public class SopaDeLetras {

	/*
	 * TODO
	 *
	 * elegir las variables adecuadas para representar una sopa de letras.
	 */

	/**
	 * Devuelve el carácter que ocupa la celda (fila, columna) de este SopaDeLetras.
	 *
	 * PRECONDICIONES
	 *
	 * 0 <= fila < número de filas de este SopaDeLetras
	 *
	 * 0 <= columna < número de columnas de este SopaDeLetras
	 */
	public char getCharAt(int fila, int columna) {
		/*
		 * TODO Completar
		 */
		return 'A';
	}

	/**
	 * Devuelve el número de columnas de este SopaDeLetras.
	 */
	public int getColumnas() {
		/*
		 * TODO Completar
		 */
		return 5;
	}

	/**
	 * Devuelve el número de filas de este SopaDeLetras.
	 */
	public int getFilas() {
		/*
		 * TODO Completar
		 */
		return 5;
	}

	/**
	 * Devuelve un NUEVO String con las letras de este SopaDeLetras que están en las
	 * casillas:
	 *
	 * 		(columna, fila) (columna+dx, fila+dy) (columna+2dx, fila+2dy)...
	 *
	 * hasta "n" letras.
	 *
	 * PRECONDICIONES
	 *
	 * 0 <= fila < número de filas de este SopaDeLetras
	 *
	 * 0 <= columna < número de columnas de este SopaDeLetras
	 *
	 * n >= 0
	 *
	 * fila + n < número de filas de este SopaDeLetras
	 *
	 * columna + n < número de columnas de este SopaDeLetras
	 */
	public String jugar(int fila, int columna, int deltaX, int deltaY, int n) {
		char[] array = new char[n];
		/*
		 * TODO Completar
		 * almacenar en array las letras de las celdas especificadas.
		 */
		String s = new String(array);
		return s;
	}

	/**
	 * Esta SopaDeLetras se modifica de acuerdo con la información contenida en el archivo
	 * de configuración especificado.
	 *
	 * @param source
	 *            ruta del archivo de configuración.
	 */
	/*
	 * FORMATO DEL ARCHIVO DE CONFIGURACION
	 *
	 * Todas las líneas del archivo deben tener la misma longitud.
	 *
	 * La primera línea indica las letras de la primera fila de la sopa de letras,
	 * de la primera columna a la última.
	 *
	 * La segunda línea indica las letras de la segunda fila de la sopa de letras;
	 * y así sucesivamente.
	 */
	public void leerConfiguracion(String source) throws FileNotFoundException {
		/*
		 * TODO Completar
		 *
		 * Modificaar el estado de esta SopaDeLetras como sea necesario,
		 * conforme al contenido del archivo de configuración.
		 *
		 * Puede ser de ayuda usar el método "open" (ver abajo.)
		 */
	}

	/**
	 * Devuelve un nuevo array con las palabras leidas del archivo con ruta "source".
	 */
	private String[] open(String source) throws FileNotFoundException {
		ArrayList<String> list = new ArrayList<>();
		Scanner scanner = new Scanner(new File(source));
		while (scanner.hasNext()) {
			String palabra = scanner.next();
			list.add(palabra);
		}
		scanner.close();
		String[] array = list.toArray(new String[0]);
		/*
		 * toArray:
		 *
		 * Returns an array containing all of the elements in this list in proper sequence
		 * (from first to last element)
		 */
		return array;
	}
}
